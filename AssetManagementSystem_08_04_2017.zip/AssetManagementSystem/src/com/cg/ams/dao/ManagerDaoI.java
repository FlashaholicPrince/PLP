/*********************************************************************
* File : AdminDAOImpl.java
* Author Name : Group 2
* Description : Implementation Of Manager Functionality
* Version : 3.1
* Last Modified Date : 03/04/2017
* Change Description : Added Comments
*********************************************************************/




package com.cg.ams.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ams.bean.Asset;
import com.cg.ams.bean.Request;
import com.cg.ams.bean.UserMaster;
import com.cg.ams.exception.*;
import com.cg.ams.logger.*;
import com.cg.ams.util.*;


@Repository("managerDAO")
public class ManagerDaoI implements ManagerDao 
{
	
	@PersistenceContext
	private EntityManager entityManager;
		
	
	Connection connection;
	PreparedStatement pstat;
	ResultSet rset;
	static Logger  mylogger=DaoLogger.mylogger;
	public ManagerDaoI()
	{
		try {
			connection = DBUtil.getConnect();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public UserMaster validateManager(int userid, String pwd, String usertype) throws ManagerException {
		boolean flag = false;
		

		UserMaster usermaster = null;
		
		try 
		{
			
			
			String sql="select u from UserMaster u where u.userId=:userid and u.userPassword=:pwd and u.userType=:usertype";
			TypedQuery<UserMaster> tQuery = entityManager.createQuery(sql, UserMaster.class);
			tQuery.setParameter("userid",  userid);
			tQuery.setParameter("pwd",  pwd);
			tQuery.setParameter("usertype",  usertype);
			
			usermaster = tQuery.getSingleResult();
			
		} 
		
		
		catch (Exception e) {
			// TODO Auto-generated catch block
e.printStackTrace();
		}
		
	
		return usermaster;
		
		
	}
	
	// ************************** View And Request ******************************* //
		@Override
		public List<Asset> viewAssets() throws ManagerException {
			// TODO Auto-generated method stub
			
			
			List<Asset> asset = null;
			try
			{
			
				String qry ="select a from Asset a where a.assetStatus=:status ";
				TypedQuery<Asset> tQuery = entityManager.createQuery(qry, Asset.class);
				tQuery.setParameter("status",  "Available");

				
				asset =  tQuery.getResultList();
				
			}
			catch(Exception e)
			{
			
				throw new ManagerException("SQL EXCEPTION");
			}
			if( asset == null || asset.isEmpty())
				throw new ManagerException("No assets found");

			return asset;
		}
		
		
		@Override
		public ArrayList<Integer> getEmployees(int mgrNo) throws ManagerException 
		{
		ArrayList<Integer> list1= new ArrayList<Integer>();
		try
		{
			String qry ="select emp.empNo from Employee emp where emp.mgr=:mgrNo ";
			TypedQuery<Integer> tQuery = entityManager.createQuery(qry, Integer.class);
			tQuery.setParameter("mgrNo",  mgrNo);

			
			list1 =  (ArrayList<Integer>) tQuery.getResultList();
		
		}
		catch(Exception e)
		{
			throw new ManagerException("SQL EXCEPTION");
		}
		return list1;
			
		}


		@Override
		public boolean insertFormDetails(Request req) throws ManagerException {
			// TODO Auto-generated method stub
			
			
			boolean flag=false;
			int reqId= -1;
	
			
			
			try
			{
				
				entityManager.persist(req);
				reqId = req.getReqId();
				
				if(reqId != -1)
				{
					flag = true;
				}
				
				
			}
				
				catch(Exception e)
				{
					e.printStackTrace();
					//throw new ManagerException("SQL EXCEPTION");
				}
		
			
			return flag;
		}


		
		// ************************** End  Of View Available Assets And Request ******************************* //
		
		
		
		
		// *********************** View Statuses Of Raised Request And Delete Request If Needed *********************** //
		
		
		@Override
		public List<Request>  viewStatus(int userId) throws ManagerException  {
			// TODO Auto-generated method stub
			
			 List<Request>  request = null;
			
			try
			{
				String qry ="select req from Request req WHERE req.mgrNum =(SELECT um.userId FROM UserMaster um WHERE um.userId=:userId)";
				TypedQuery<Request> tQuery = entityManager.createQuery(qry, Request.class);
				tQuery.setParameter("userId",  userId);

				request =    tQuery.getResultList();
			}
			catch (Exception e)
			{
				e.printStackTrace();
				/*// TODO Auto-generated catch block
				throw new ManagerException("SQL EXCEPTION");*/
			}
			
			
			
			return request;
		}

		
		@Override
		public boolean deleteRequest(int reqId) throws ManagerException {
			// TODO Auto-generated method stub
			boolean flag=false;
			
			try
			{
				Request request = entityManager.find(Request.class, reqId);
				
				entityManager.remove(request);
				 flag= true;
			}
			
				catch(Exception e)
				{
					throw new ManagerException("SQL EXCEPTION");
				}
			return flag;
		}

		
		
		// *********************** View Statuses Of Raised Request And Delete Request If Needed (END)******************* //
		
	
}
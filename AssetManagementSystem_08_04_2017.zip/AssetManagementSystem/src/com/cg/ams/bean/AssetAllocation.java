package com.cg.ams.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Asset_Allocation")
public class AssetAllocation {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "myseq1")
	@SequenceGenerator(name="myseq1",sequenceName="ALLOT_ID_SEQ", initialValue = 1)
	@Column(name="AllocationId")
	private int allocationId;
	
	@Column(name="assetId")
	@NotNull(message = "Assetid Cannot be Empty")
	private int assetId;
	
	
	@Column(name="empNo")
	@NotNull(message = "Employee Number Cannot be Empty")
	private int empNo;
	

	@Column(name="Allocation_date")
	//@NotEmpty(message = "Allocation Date is required")
	private Date allocationDate;
	

	@Column(name="Release_date")
//	@NotEmpty(message = "Release Date is required")
	private Date releaseDate;
	
	public AssetAllocation()
	{
		
	}

	public int getAllocationId() {
		return allocationId;
	}

	public void setAllocationId(int allocationId) {
		this.allocationId = allocationId;
	}

	public int getAssetId() {
		return assetId;
	}

	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public Date getAllocationDate() {
		return allocationDate;
	}

	public void setAllocationDate(Date allocationDate) {
		this.allocationDate = allocationDate;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	@Override
	public String toString() {
		return "AssetAllocation [allocationId=" + allocationId + ", assetId="
				+ assetId + ", empNo=" + empNo + ", allocationDate="
				+ allocationDate + ", releaseDate=" + releaseDate + "]";
	}
}

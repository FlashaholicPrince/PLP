package com.cg.ams.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class UserMaster {
	
	@Id
	@Column(name="userId")
	private int userId;
	
	@Column(name="userName")
	@NotEmpty(message = "User Name Cannot be Empty")
	private String userName;
	
	@Column(name="userPassword")
	@NotEmpty(message = "User Password Cannot be Empty")
	private String userPassword;
	
	@Column(name="userType")
	@NotEmpty(message = "User Type Cannot be Empty")
	private String userType;
	
	public UserMaster()
	{
		
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	
	@Override
	public String toString() {
		return "UserMaster [userId=" + userId + ", userName=" + userName
				+ ", userPassword=" + userPassword + ", userType=" + userType
				+ "]";
	}
	
}
	
	
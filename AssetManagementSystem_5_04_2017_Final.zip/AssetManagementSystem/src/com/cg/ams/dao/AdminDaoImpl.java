/*********************************************************************
* File : AdminDAOImpl.java
* Author Name : Group 2
* Description : Implementation Of Admin Functionality
* Version : 6.0
* Last Modified Date : 03/04/2017
* Change Description : Added Comments
*********************************************************************/


package com.cg.ams.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ams.bean.Asset;
import com.cg.ams.bean.AssetAllocation;
import com.cg.ams.bean.Request;
import com.cg.ams.bean.UserMaster;
import com.cg.ams.exception.*;
import com.cg.ams.util.*;
import com.cg.ams.logger.*;


@Repository("admindao")
public class AdminDaoImpl implements AdminDao 
{

	@PersistenceContext
	private EntityManager entityManager;
	
	
	
	Connection connection;
	PreparedStatement pstmt;
	static Logger  mylogger=DaoLogger.mylogger;
	public AdminDaoImpl()
	{
		try {
			connection = DBUtil.getConnect();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	@Override
	public UserMaster validateAdmin(int userid, String pwd, String usertype) throws AdminException 
	{
		
		UserMaster usermaster = null;
		
		try 
		{
			System.out.println("in dao"+userid+pwd+usertype);
			
			String sql="select u from UserMaster u where u.userId=:userid and u.userPassword=:pwd and u.userType=:usertype";
			TypedQuery<UserMaster> tQuery = entityManager.createQuery(sql, UserMaster.class);
			tQuery.setParameter("userid",  userid);
			tQuery.setParameter("pwd",  pwd);
			tQuery.setParameter("usertype",  usertype);
			
			usermaster = tQuery.getSingleResult();
			System.out.println("usermaster"+usermaster);
		} 
		
		
		catch (Exception e) {
			// TODO Auto-generated catch block
e.printStackTrace();
		}
		
	
		return usermaster;
		
		
	}

	

	//************************** Adding Of Asset ****************************** //
	@Override
	public boolean addAsset(Asset asset) throws AdminException 
	{
		System.out.println("Asset"+asset);
		try
		{
			entityManager.persist(asset);
			return true;
		}
		catch(Exception e)
		{
			throw new AdminException(e.getMessage());
		}
		
		
		
	}
	
	
		
	// *************************** End Of Add Assets ************************* //	
	
	@Override
	public HashMap<Integer, Asset> viewAssets() throws AdminException {
		
		

		 HashMap<Integer, Asset> asset = null;
		try
		{
		
			String qry ="select a from Asset a ";
			TypedQuery<Asset> tQuery = entityManager.createQuery(qry, Asset.class);
	
			asset = (HashMap<Integer, Asset>) tQuery.getResultList();
			
			System.out.println("asass"+asset);
			
		}
		catch(Exception e)
		{
		e.printStackTrace();
			//throw new AdminException("SQL EXCEPTION");
		}
		if( asset == null || asset.isEmpty())
			throw new AdminException("No assets found");

		return asset;
	}

	@Override
	public Asset getAssetDetails(int assetId) throws AdminException
	{
		Asset asset=new Asset();
		String qry="SELECT * FROM ASSET WHERE ASSETID=?";
		try
		{
			pstmt=connection.prepareStatement(qry);
			pstmt.setInt(1, assetId);
			ResultSet res=pstmt.executeQuery();
			while(res.next())
			{
				asset.setAssetId(res.getInt(1));
				asset.setAssetName(res.getString(2));
				asset.setAssetDes(res.getString(3));
				asset.setAssetQuantity(res.getInt(4));
				asset.setAssetStatus(res.getString(5));
			}
		}
		catch(SQLException e)
		{
			throw new AdminException("Unable To Get The Available Asset Details");
		}
		
		return asset;
		
	}
	
	// ************************* Modify Assets *************************** //
	@Override
	public boolean modifyAsset(Asset asset) throws AdminException {
		
		boolean flag=false;
		
		String qry="update asset set assetname=?,assetdes=?,quantity=?,status=? where assetid=?";

		try {
			PreparedStatement pstmt = connection.prepareStatement(qry);
			if(validateAssetId(asset.getAssetId(),asset.getAssetName()))
			{	
			pstmt.setString(1,asset.getAssetName());
			pstmt.setString(2,asset.getAssetDes());
			pstmt.setInt(3, asset.getAssetQuantity());
			pstmt.setString(4, asset.getAssetStatus());
			pstmt.setInt(5, asset.getAssetId());
			int row = pstmt.executeUpdate();
			if(row>0)
			{
			flag=true;
			mylogger.info("Assets modified successfully");
			}
			
			else
			{
				mylogger.error("Error while updating asset");

				throw new AdminException("Cannot update asset");
			}
			}
			
		}
		catch (SQLException e) 
		{
			
			throw new AdminException("Unable To Update Asset Reason : Unable To Update In Database");
		}
		
		return flag;
		
	}
	
	
	
	private boolean validateAssetId(int aId,String aName) throws AdminException {
		
		boolean flag=false;
		String qry="SELECT COUNT(*) FROM asset WHERE ASSETID=? AND ASSETNAME=?";
		try {
			pstmt=connection.prepareStatement(qry);
			pstmt.setInt(1, aId);
			pstmt.setString(2, aName);
			ResultSet res=pstmt.executeQuery();
			res.next();
			if(res.getInt(1)>0)
			{
				flag=true;
			}
			
			else
			{
				mylogger.error("can not fetch asset id and asset name");

				throw new AdminException("asset id and asset name not found");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AdminException("Unable To Validate AssetId Due To Some Database Error");
		}
		
		return flag;
	}
	
	
	
	// ************************* End Of Modify Assets *************************** //
	
	// ************************* View Request *********************************** // 
	@Override
	public HashMap<Integer, Request> viewAllRequest() throws AdminException {
		HashMap<Integer,Request>map = new HashMap<Integer,Request>();
		
		String sql = "SELECT * FROM Request WHERE STATUS='Pending'";
		
		try {
			Statement stmt = connection.createStatement();
			ResultSet res = stmt.executeQuery(sql);
			
			while(res.next())
			{
				Request req = new Request();
				
				req.setReqId(res.getInt(1));
				req.setMgrNum(res.getInt(2));
				req.setEmpNo(res.getInt(3));
				req.setAssetId(res.getInt(4));
				req.setAssetQuantity(res.getInt(5));
				req.setStatus(res.getString(6));
				req.setReleaseDate(res.getDate(7));
				
				map.put(res.getInt(1),req);
				
			}
			
			if(map.size()==0)
			{
				mylogger.error("Unable to fetch records");

			throw new AdminException("No Results Found");
				
			}
			else
			{
				mylogger.info(map);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AdminException("Unable To View Request Due To Some Database Error");
		}
		
		return map;
	}

	// ******************* Accepting The Request Of The Asset ***************************   //
	@Override
	public boolean acceptManagerRequest(int reqId) throws AdminException {
		boolean flag=false;
		
		Request req = new Request();
		
		int quantity=getQuantity(reqId);
		
		int assetId = getAssetId(reqId);
		try {
		if(updateQuantity(assetId,quantity))
		
		{
			
		String qry="update request set status='Accepted' where REQID=?";
		
			PreparedStatement pstmt = connection.prepareStatement(qry);
			pstmt.setInt(1,reqId);
			int row = pstmt.executeUpdate();
			if(row>0)
			{
				
				AssetAllocation aa=selectRequest(reqId);
				insertAsset(aa);
				flag=true;
				
			}
			else
			{
				mylogger.error("unable to accept the status");

				throw new AdminException("Not updated");
			}
		}
		else
		{
			throw new AdminException("Sorry The Requested Number Of Assets Are Not Available");
		}
		}
		catch(SQLException e)
		{
			throw new AdminException("Unable To Accept The Request Due To Some Database Error");
		}
		return flag;
	}
	
	
	public int getAssetId(int reqId) throws AdminException
	{
		int assetId=0;
		String qry="SELECT assetId from request where REQID=?";
		PreparedStatement pstmt;
		try {
			pstmt = connection.prepareStatement(qry);
			pstmt.setInt(1,reqId);
			ResultSet res=pstmt.executeQuery();
			if(res.next())
			{
				assetId=res.getInt(1);
			}
			else
			{
				throw new AdminException("No such assetid exists");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			throw new AdminException("Unable To Get The Unique Id From The Database");
		}
		
		return assetId;
	}
	

	private int getQuantity(int reqId) throws AdminException {
		
			
		int quantity=0;
		String qry = "SELECT quantity FROM request WHERE REQID=?";
		try {
				PreparedStatement pstmt = connection.prepareStatement(qry);
				pstmt.setInt(1, reqId);
				ResultSet res = pstmt.executeQuery();
				while(res.next())
				{
					quantity=res.getInt(1);
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AdminException("SQL EXCEPTION ");
		}
		
			return quantity;
	}
	
	
	private boolean updateQuantity(int aId,int quantity) throws AdminException {
		
		boolean flag = false;
		
		String qry = "UPDATE asset SET quantity=? WHERE ASSETID=? AND QUANTITY >= ?";
		{
			try {
					PreparedStatement pstmt = connection.prepareStatement(qry);
					pstmt.setInt(1,quantity);
					pstmt.setInt(2,aId);
					pstmt.setInt(3, quantity);
					int row = pstmt.executeUpdate();
					if(row>0)
					{
						flag=true;
						mylogger.info("Quantity is updated");
					
					}
					
					else
					{
						mylogger.error("unable to update asset quantity");
						//throw new AdminException("Quantity is not available");
					}
				}
			catch(SQLException e)
			{
				throw new AdminException("Unable To Update The Quantity Due To Database Error");
			}
			return flag;
		}		
}
	
	
	public AssetAllocation selectRequest(int reqId) throws AdminException
	{
		String qry="SELECT ASSETID,EMPNO,RELEASE_DATE FROM REQUEST WHERE REQID=?";
		
		AssetAllocation aa = new AssetAllocation();
		try {
			pstmt=connection.prepareStatement(qry);
			pstmt.setInt(1,reqId);
			ResultSet res = pstmt.executeQuery();
			
			while(res.next())
			{
				aa.setAssetId(res.getInt(1));
				aa.setEmpNo(res.getInt(2));
				aa.setReleaseDate(res.getDate(3));
				//insertAsset(reqId,aa);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AdminException("SQL EXCEPTION ");
		}
		return aa;
	}
	
	private void insertAsset(AssetAllocation aa) throws AdminException {
		
		String qry = "INSERT INTO ASSET_ALLOCATION VALUES(?,?,?,SYSDATE,?)";
		
		{
			try {
				pstmt = connection.prepareStatement(qry);
				int aId=getAllocationId();
				pstmt.setInt(1, aId);
				pstmt.setInt(2,aa.getAssetId());
				pstmt.setInt(3,aa.getEmpNo());
				pstmt.setDate(4,aa.getReleaseDate());
				pstmt.executeUpdate();
				
		
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new AdminException("Unable To Insert The Asset Into The Database");
			}
		}
	}
	

	private int getAllocationId() throws AdminException {
		
		int aId=0;
		String qery="SELECT ALLOT_ID_SEQ.nextval from dual";
		PreparedStatement pstmt;
		try {
			pstmt = connection.prepareStatement(qery);
			ResultSet res=pstmt.executeQuery();
			if(res.next())
			{
				aId=res.getInt(1);
			}
			
			else
			{
				throw new AdminException("No such allocationid");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
		}
		
		return aId;
		
		
	}
	
	// *********************** End Of Accepting The Request Of The Asset ************************************** //
	
	
	@Override
	public boolean rejectManagerRequest(int reqId) throws AdminException {
		
		boolean flag=false;
		
		Request req = new Request();
		String qry="update request set status='Rejected' where REQID=?";
		try {
			PreparedStatement pstmt = connection.prepareStatement(qry);
			pstmt.setInt(1,reqId);
			int row = pstmt.executeUpdate();
		
			if(row>0)
			{
				flag=true;
				mylogger.info("Request Rejected");
				
			}
			
			else
			{
				mylogger.error("unable to update request");

				throw new AdminException("Not updated");
			}
		}
		catch(SQLException e)
		{
			throw new AdminException("Unable To Reject Request Because Of Database Error");
		}
		return flag;
	}
	
	

		
}





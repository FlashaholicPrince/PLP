package com.cg.ams.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
public class Employee {

	@Id
	@Column(name="empNo")
	private int empNo;
	
	@Column(name="eName")
	@NotEmpty(message = "Employee Name Cannot be Empty")
	private String eName;
	
	@Column(name="job")
	@NotEmpty(message = "Job Cannot be Empty")
	private String job;
	
	@Column(name="mgr")
	@NotNull(message = "Employee Manager Cannot be Empty")
	private int mgr;
	
	@Column(name="hiredate")
	@NotEmpty(message = "Employee Hiredate must be Specified")
	private String date;
	
	@Column(name="Dept_ID")
	@NotNull(message = "Employee must have a DepartmentId")
	private int deptId;
	
	public Employee()
	{
		
	}

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public int getMgr() {
		return mgr;
	}

	public void setMgr(int mgr) {
		this.mgr = mgr;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	@Override
	public String toString() {
		return "Employee [empNo=" + empNo + ", eName=" + eName + ", job=" + job
				+ ", mgr=" + mgr + ", date=" + date + ", deptId=" + deptId
				+ "]";
	}
	
}

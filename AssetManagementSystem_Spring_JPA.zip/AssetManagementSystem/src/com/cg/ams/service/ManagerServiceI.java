package com.cg.ams.service;


import java.util.ArrayList;
import java.util.HashMap;

import com.cg.ams.bean.*;
import com.cg.ams.dao.*;
import com.cg.ams.exception.ManagerException;

public class ManagerServiceI implements ManagerService{

	ManagerDao dao;
	
	public ManagerServiceI()
	{
		dao = new ManagerDaoI();
	}
	public void setDao(ManagerDao dao)
	{
		this.dao = dao;
	}
	

	@Override
	public boolean insertFormDetails(Request req) throws ManagerException {
		// TODO Auto-generated method stub
		return dao.insertFormDetails(req);
	}



	@Override
	public HashMap<Integer, Request> viewStatus(int userId)
			throws ManagerException {
		// TODO Auto-generated method stub
		return dao.viewStatus(userId);
	}



	@Override
	public boolean deleteRequest(int key1) throws ManagerException {
		// TODO Auto-generated method stub
		return dao.deleteRequest(key1);
	}



	@Override
	public HashMap<Integer, Asset> viewAssets() throws ManagerException {
		// TODO Auto-generated method stub
		return dao.viewAssets();
	}



	@Override
	public boolean validateManager(String userid, String pwd, String usertype) throws ManagerException {
		// TODO Auto-generated method stub
		return dao.validateManager(userid, pwd, usertype);
	}






	@Override
	public ArrayList<Integer> getEmployees(int mgrNo) throws ManagerException {
		// TODO Auto-generated method stub
		return dao.getEmployees(mgrNo);
	}
	



	/*@Override
	public ArrayList<Request> viewStatus(int userId) throws ManagerException {
		// TODO Auto-generated method stub
		return dao.viewStatus(userId);*/
	}



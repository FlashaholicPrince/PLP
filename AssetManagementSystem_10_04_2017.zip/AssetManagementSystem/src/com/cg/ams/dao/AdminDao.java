package com.cg.ams.dao;


import java.util.List;

import com.cg.ams.bean.Request;
import com.cg.ams.bean.Asset;
import com.cg.ams.bean.UserMaster;
import com.cg.ams.exception.*;


public interface AdminDao
{

	// Validate  Admin And Add Assets
	public UserMaster validateAdmin(int userid,String pwd,String usertype)throws AdminException;
	public boolean addAsset(Asset asset) throws AdminException;
	
	
	
	// Modify Assets
	public List<Asset> viewAssets() throws AdminException;
	Asset getAssetDetails(int assetId) throws AdminException;
	public boolean modifyAsset(Asset asset) throws AdminException;

	
	
	
	// View Request Methods
	public List<Request> viewAllRequest() throws AdminException;	
	public boolean acceptManagerRequest(int key) throws AdminException;
	public boolean rejectManagerRequest(int key) throws AdminException;
	
	
}

package com.cg.ams.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Asset {

	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_Seq")
	@SequenceGenerator(name="my_Seq", sequenceName ="ASSET_ID_SEQ")
	private int assetId;
	
	
	private String assetName;
	private String assetDes;
	private int assetQuantity;
	private String assetStatus;

	public Asset()
	{
		
	}

	public int getAssetId() {
		return assetId;
	}

	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetDes() {
		return assetDes;
	}

	public void setAssetDes(String assetDes) {
		this.assetDes = assetDes;
	}

	public int getAssetQuantity() {
		return assetQuantity;
	}

	public void setAssetQuantity(int assetQuantity) {
		this.assetQuantity = assetQuantity;
	}

	public String getAssetStatus() {
		return assetStatus;
	}

	public void setAssetStatus(String assetStatus) {
		this.assetStatus = assetStatus;
	}

	@Override
	public String toString() {
		return "Asset [assetId=" + assetId + ", assetName=" + assetName
				+ ", assetDes=" + assetDes + ", assetQuantity=" + assetQuantity
				+ ", assetStatus=" + assetStatus + "]";
	}
	
}

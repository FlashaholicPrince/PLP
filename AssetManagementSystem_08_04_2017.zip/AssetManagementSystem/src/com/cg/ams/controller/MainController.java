package com.cg.ams.controller;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ams.bean.Asset;
import com.cg.ams.bean.Request;
import com.cg.ams.bean.UserMaster;
import com.cg.ams.exception.AdminException;
import com.cg.ams.exception.ManagerException;
import com.cg.ams.service.AdminService;
import com.cg.ams.service.AdminServiceImpl;
import com.cg.ams.service.ManagerService;
import com.cg.ams.service.ManagerServiceImpl;


@Controller
public class MainController
{
		
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private ManagerService managerService;
	
	

	public ManagerService getManagerService() {
		return managerService;
	}


	public void setManagerService(ManagerService managerService) {
		this.managerService = managerService;
	}


	public MainController(AdminService adminService,
			ManagerService managerService) {
		super();
		this.adminService = adminService;
		this.managerService = managerService;
	}


	public AdminService getAdminService() {
		return adminService;
	}


	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}



	public MainController(AdminService adminService) {
		super();
		this.adminService = adminService;
	}


	public MainController() {
		super();
		
	}




	@RequestMapping("Login")
	public String getAdminHomePage(@RequestParam("id") int id, @RequestParam("pwd") String pwd, @RequestParam("usertype") String usertype 
			,HttpSession session, Model model)
	{			
		session.setAttribute("userId", id);
		UserMaster user = null;
		if(usertype.equalsIgnoreCase("admin"))
		{
			
			try 
			{
				user = adminService.validateAdmin(id, pwd, usertype);
				
				if(user != null)
				{
						return "Admin";
				}
				else
				{
					model.addAttribute("errMsg","Invalid user id or password of admin");
					return "index";
				}
				
			}
			catch (AdminException e)
			{
				e.getMessage();
			}
		}
		else
		{
			
				try 
				{
					user = managerService.validateManager(id, pwd, usertype);
					if(user != null)
					{
						
							return "Manager";
					}
					else
					{
						model.addAttribute("errMsg","Invalid user id or password of admin");
						return "index";
					}
				} 
				catch (ManagerException e) 
				{
				
					e.getMessage();
				}
				
		
		}
		return "index";
	}
	
	
	@RequestMapping("Adminhome")
	public String getAdminHomePage(HttpSession session)
	{
		
		session.getAttribute("userId");
		return "Admin";
		
	}
	
	@RequestMapping("Managerhome")
	public String getManagerHomePage(HttpSession session)
	{
		session.getAttribute("userId");
		
		return "Manager";
		
	}
	
	
	
	
	@RequestMapping("AddAsset")
	public String getAddAssetPage(Model model)
	{
		List<String> status = new ArrayList<String>();
		
		status.add("Available");
		
		model.addAttribute("status",status);
		model.addAttribute("asset",new Asset());
		
		return "Addassets";
	}
	
	@RequestMapping("AddDetails")
	public ModelAndView addAsset(@ModelAttribute("asset") @Valid Asset asset, BindingResult result,  Model model)
	{
		

		if(result.hasErrors() == true)
		{
			List<String> status = new ArrayList<String>();
			
			status.add("Available");
			
			model.addAttribute("status",status);
			model.addAttribute("asset",asset);
			
			return new ModelAndView("ErrorPage");
		}
		
		else
		{
				
			try
			{
				adminService.addAsset(asset);
				model.addAttribute("sucessMsg","Asset Added Successfully With Id" +asset.getAssetId());
				return new ModelAndView("Success");

			} 
			catch (AdminException e) 
			{
				model.addAttribute("errMsg","Asset Could Not Be Added Due To Some Database Error");
				return new ModelAndView("ErrorPage");
			}
		}
		
		
	}
	
	
	@RequestMapping("ModifyAsset")
	public String getAssets(Model model)
	{

		 List<Asset> asset = null;
		try 
		{
			asset = adminService.viewAssets();
			
			
			model.addAttribute("Asset",asset);
		}
		catch (Exception e) 
		{
			e.getMessage();
		}
		return "ViewAssetsForAdmin";
	}
	
	@RequestMapping("modify")
	public String getModifyForm(@RequestParam("id") int assetId, Model model)
	{
		List<String> status = new ArrayList<String>();
		status.add("Available");
		status.add("Not Available");
		
		model.addAttribute("status",status);
		Asset asset = null;
		try 
		{
			asset = adminService.getAssetDetails(assetId);
			
			model.addAttribute("asset",asset);
		}
		catch (AdminException e) 
		{
			
		}
		return "modifyform";
	}
	
	
	@RequestMapping("AddModifiedDetails")
	public String modifyFormPage(@ModelAttribute("asset") @Valid Asset asset, BindingResult result,  Model model)
	{
		if(result.hasErrors() == true)
		{
			List<String> status = new ArrayList<String>();
			status.add("Available");
			status.add("Not Available");
			
			model.addAttribute("status",status);
			
			model.addAttribute("asset",asset);

			return "modifyform";
		}
		
		else
		{
				
			try
			{
				adminService.modifyAsset(asset);
				model.addAttribute("sucessMsg","Asset Modified Successfully");
				return "Success";
			} 
			catch (AdminException e) 
			{
				model.addAttribute("errMsg","Asset Could Not Be Modified Due To Some Database Error");
				return "ErrorPage";

			}
		}
		
	
	}

	@RequestMapping("ViewAllRequest")
	public String getViewAllRequestPage(Model model)
	
	{
		 List<Request> request = null;
			try 
			{
				
				
				request = adminService.viewAllRequest();
				
				
				if(request==null || request.isEmpty())
				{
					return "NoRequest";
				}
				else
				{
				model.addAttribute("request",request);
				return "viewAllRequest";
				}
			}
			catch (Exception e) 
			{
				return "NoRequest";
				
			}
			
		
	}
	
	@RequestMapping("acceptRequest")
	public String acceptRequest(@RequestParam("reqId")int reqId,   Model model)
	{
		
		 List<Request> request = null;
			try 
			{
				Boolean flag = adminService.acceptManagerRequest(reqId);
				if(flag == true)
				{
					
					request = adminService.viewAllRequest();
					if(request==null || request.isEmpty())
					{
						return "NoRequest";
					}
					
					model.addAttribute("request",request);
					return "viewAllRequest";
				}
				
			}
			catch (Exception e) 
			{
				e.getMessage();
			}
			return null;
		
		
	}
	
	
	@RequestMapping("rejectRequest")
	public String rejectRequest(@RequestParam("reqId")int reqId, Model model)
	{
		
		 List<Request> request = null;
			try 
			{
				Boolean flag = adminService.rejectManagerRequest(reqId);
				if(flag == true)
				{
					
					request = adminService.viewAllRequest();
					
					
					model.addAttribute("request",request);
					return "viewAllRequest";
				}
				
			}
			catch (Exception e) 
			{
				e.getMessage();
			}
		return null;
		
	}
	
	
	//======================================================================================================================
	//======================================MANAGER CONTROLLER================================================================================
	
	
	@RequestMapping("ViewAssets")
	public String getViewAssetsPage(@RequestParam("userId")int userId ,Model model)
	{
		List<Asset> asset = null;
		
		try 
		{
			asset = managerService.viewAssets();
			model.addAttribute("asset",asset);
			
			return "viewAssets";
			
		}
		catch (Exception e) 
		{
			e.getMessage();
		}
		
		return "Manager";
	}
	
	@RequestMapping("raiseRequest")
	public String getRaiseRequestForm (@RequestParam("id")int assetid, HttpSession session, Model model)
	{
		int mgrNo =  (int) session.getAttribute("userId");
		
		List<Integer> empList= null;
		try 
		{
			 empList = managerService.getEmployees(mgrNo);
			
			model.addAttribute("empList",empList);
			model.addAttribute("mgrNo",mgrNo);
			model.addAttribute("assetid",assetid);
			
		
			model.addAttribute("request",new Request());
			return "RaiseRequestForm";
		}
		catch (ManagerException e) 
		{
			
		}
		return null;
	}
	
	@RequestMapping("insertRequest")
	public ModelAndView insertRequest(@ModelAttribute("request") @Valid Request request, BindingResult result,  Model model)
	{
		

		if(result.hasErrors() == true)
		{
			
			//String No = (String) session.getAttribute("userId");
			//int mgrNo = Integer.parseInt(No);
			List<Integer> empList= null;

			 //empList = managerService.getEmployees(mgrNo);
				
				model.addAttribute("empList",empList);
				/*	model.addAttribute("mgrNo",mgrNo);
				model.addAttribute("assetid",assetid);
				model.addAttribute("assetName",assetName);*/
				model.addAttribute("request",request);
			
			return new ModelAndView("RaiseRequestForm");
		}
		
		else
		{
				
			try
			{
				
				managerService.insertFormDetails(request);
				model.addAttribute("sucessMsg","Request Raised Successfully With Id" +request.getReqId());
				return new ModelAndView("SuccessMgr");
			
			} 
			catch (ManagerException e) 
			{
				model.addAttribute("errMsg","Request Could Not Be Raised Due To Some Error");
				return new ModelAndView("ErrorPageMgr");

			}
		}
	
		
	}
	
	@RequestMapping("ViewStatus")
	public String getViewStatusPage(@RequestParam("userId")int userId,Model model)
	
	{
		 List<Request> request = null;
			try 
			{
				request = managerService.viewStatus(userId);
				model.addAttribute("request",request);
			}
			catch (Exception e) 
			{
				e.getMessage();
			}
		return "viewrequest";
		
	}
	
	@RequestMapping("deleteRequest")
	public String deleteRequest(@RequestParam("reqId")int reqId,HttpSession session, Model model)
	{
		List<Request> request = null;
		try 
		{
			int userId = (int) session.getAttribute("userId");
			managerService.deleteRequest(reqId);
			request = managerService.viewStatus(userId);
			model.addAttribute("request",request);
			return "viewrequest";
		}
		catch (Exception e) 
		{
			e.getMessage();
			return "viewrequest";
		}
	}
	
	
	
	
	
	
	
	

}

package com.cg.ams.service;

import java.util.ArrayList;
import java.util.HashMap;









import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ams.bean.Asset;
import com.cg.ams.bean.Request;
import com.cg.ams.bean.UserMaster;
import com.cg.ams.dao.*;
import com.cg.ams.exception.*;


@Service("adminService")
@Transactional
public class AdminServiceImpl implements AdminService{

	@Autowired
	private AdminDao admindao;
	
	public AdminDao getAdmindao() {
		return admindao;
	}

	public void setAdmindao(AdminDao admindao) {
		this.admindao = admindao;
	}

	
	public AdminServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public AdminServiceImpl(AdminDao admindao) {
		super();
		this.admindao = admindao;
	}

	@Override
	public boolean addAsset(Asset asset) throws AdminException {
		// TODO Auto-generated method stub
		return admindao.addAsset(asset);
	}

	@Override
	public boolean modifyAsset(Asset asset) throws AdminException {
		// TODO Auto-generated method stub
		return admindao.modifyAsset(asset);
	}

	

	@Override
	public boolean acceptManagerRequest(int key) throws AdminException {
		// TODO Auto-generated method stub
		return admindao.acceptManagerRequest(key);
	}

	@Override
	public boolean rejectManagerRequest(int key) throws AdminException {
		// TODO Auto-generated method stub
		return admindao.rejectManagerRequest(key);
	}

	@Override
	public UserMaster validateAdmin(int userid, String pwd, String usertype) throws AdminException{
		// TODO Auto-generated method stub
		return admindao.validateAdmin(userid,pwd,usertype);
	}

	

	
	@Override
	public Asset getAssetDetails(int assetId) throws AdminException {
		// TODO Auto-generated method stub
		return admindao.getAssetDetails(assetId);
	}

	@Override
	public List<Request> viewAllRequest() throws AdminException {
		// TODO Auto-generated method stub
		return admindao.viewAllRequest();
	}

	@Override
	public List<Asset> viewAssets() throws AdminException {
		// TODO Auto-generated method stub
		return admindao.viewAssets();
	}

}

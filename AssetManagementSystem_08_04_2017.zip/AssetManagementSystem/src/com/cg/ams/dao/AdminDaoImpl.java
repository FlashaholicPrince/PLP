/*********************************************************************
* File : AdminDAOImpl.java
* Author Name : Group 2
* Description : Implementation Of Admin Functionality
* Version : 6.0
* Last Modified Date : 03/04/2017
* Change Description : Added Comments
*********************************************************************/


package com.cg.ams.dao;


import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ams.bean.Asset;
import com.cg.ams.bean.AssetAllocation;
import com.cg.ams.bean.Request;
import com.cg.ams.bean.UserMaster;
import com.cg.ams.exception.*;
import com.cg.ams.util.*;
import com.cg.ams.logger.*;


@Repository("admindao")
public class AdminDaoImpl implements AdminDao 
{

	@PersistenceContext
	private EntityManager entityManager;
	
	static Logger  mylogger=DaoLogger.mylogger;
	public AdminDaoImpl()
	{
		
	}
	 
	
	public EntityManager getEntityManager() {
		return entityManager;
	}



	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}



	public AdminDaoImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}



	@Override
	public UserMaster validateAdmin(int userid, String pwd, String usertype) throws AdminException 
	{
		
		UserMaster usermaster = null;
		
		try 
		{
			
			
			String sql="select u from UserMaster u where u.userId=:userid and u.userPassword=:pwd and u.userType=:usertype";
			TypedQuery<UserMaster> tQuery = entityManager.createQuery(sql, UserMaster.class);
			tQuery.setParameter("userid",  userid);
			tQuery.setParameter("pwd",  pwd);
			tQuery.setParameter("usertype",  usertype);
			
			usermaster = tQuery.getSingleResult();
			
		} 
		
		
		catch (Exception e) 
		{
			throw new AdminException(" You are not a valid admin");
		}
		
	
		return usermaster;
		
		
	}

	

	//************************** Adding Of Asset ****************************** //
	@Override
	public boolean addAsset(Asset asset) throws AdminException 
	{
		boolean flag=false;
		int assetId= -1;
		
		try
		{
			entityManager.persist(asset);
			assetId=asset.getAssetId();
			if(assetId != -1)
			{
				flag = true;
			}
			
		}
		catch(Exception e)
		{
			throw new AdminException("Unable to add the asset");
		}
		
		return flag;
		
		
		
	}
	
	
		
	// *************************** End Of Add Assets ************************* //	
	
	@Override
	public List<Asset> viewAssets() throws AdminException {
		
		

		List<Asset> asset = null;
		try
		{
		
			String qry ="select a from Asset a ";
			TypedQuery<Asset> tQuery = entityManager.createQuery(qry, Asset.class);
	
			asset =  tQuery.getResultList();
			
			
			
		}
		catch(Exception e)
		{
			throw new AdminException("SQL EXCEPTION");
		}
		if( asset == null || asset.isEmpty())
			throw new AdminException("No assets found");

		return asset;
	}

	@Override
	public Asset getAssetDetails(int assetId) throws AdminException
	{
		Asset asset=new Asset();
		
		try
		{
			
			asset = entityManager.find(Asset.class, assetId);
			
				
		}
		catch(Exception e)
		{
			throw new AdminException("Unable To Get The Available Asset Details");
		}
		
		return asset;
		
	}
	
	// ************************* Modify Assets *************************** //
	@Override
	public boolean modifyAsset(Asset asset) throws AdminException {
		
		boolean flag=false;
		
		
		try 
		{
			if(validateAssetId(asset.getAssetId(),asset.getAssetName()))
			{	
				
				entityManager.merge(asset);
				entityManager.flush();
				mylogger.info("Assets modified successfully");
			}
			
			else
			{
				mylogger.error("Error while updating asset");

				throw new AdminException("Cannot update asset");
			}
		
			
		}
		catch (Exception e) 
		{
			throw new AdminException("Unable To Update Asset Reason : Unable To Update In Database");
		}
		
		return flag;
		
	}
	
	
	
	private boolean validateAssetId(int aId,String aName) throws AdminException {
		
		boolean flag=false;
		Asset asset = null;
		try 
		{
			String qry="SELECT a FROM Asset a WHERE a.assetId=:aId AND a.assetName=:aName";
			TypedQuery<Asset> tQuery = entityManager.createQuery(qry, Asset.class);
			tQuery.setParameter("aId",  aId);
			tQuery.setParameter("aName",  aName);

			asset = tQuery.getSingleResult();
			if(asset != null)
			{
				
				flag=true;
			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			throw new AdminException("Unable To Validate AssetId Due To Some Database Error");
		}
		
		return flag;

	}
	
	
	
	// ************************* End Of Modify Assets *************************** //
	
	// ************************* View Request *********************************** // 
	@Override
	public List<Request> viewAllRequest() throws AdminException {
		
		List<Request> request = null;
		
		try 
		{

			String sql = "SELECT req FROM Request req WHERE req.status=:status";
			TypedQuery<Request> tQuery = entityManager.createQuery(sql, Request.class);
			tQuery.setParameter("status",  "PENDING");
			
			request =  tQuery.getResultList();
			
			
			
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			throw new AdminException("Unable To View Request Due To Some Database Error");
		}
		
		return request;
	}

	// ******************* Accepting The Request Of The Asset ***************************   //
	@Override
	public boolean acceptManagerRequest(int reqId) throws AdminException {
		boolean flag=false;
		
		Request req = new Request();
		
		int quantity=getQuantity(reqId);
		int assetId = getAssetId(reqId);
		

		try
		{
			if(updateQuantity(assetId,quantity))
			{
				
				req = entityManager.find(Request.class, reqId);
				req.setStatus("ACCEPTED");
				
				entityManager.merge(req);
				entityManager.flush();

					AssetAllocation aa=selectRequest(reqId);
					
					insertAsset(aa);
					flag=true;			
			
			}
			else
			{
				mylogger.error("unable to accept the status");
				
				throw new AdminException("Not updated");
			}

		
		}
		catch(Exception e)
		{
			throw new AdminException("Unable To Accept The Request Due To Some Database Error");
		}
		return flag;
	}
	
	
	public int getAssetId(int reqId) throws AdminException
	{
		int assetId=0;
		try 
		{
			String qry="SELECT req.assetId from Request req where req.reqId=:reqId";
			TypedQuery<Integer> tQuery = entityManager.createQuery(qry, Integer.class);
			tQuery.setParameter("reqId",  reqId);
			assetId=tQuery.getSingleResult();
		}
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			
			throw new AdminException("Unable To Get The Unique Id From The Database");
		}
		
		return assetId;
	}
	

	private int getQuantity(int reqId) throws AdminException {
		
			
		int quantity=0;
		try {
			String qry = "SELECT req.assetQuantity FROM Request req WHERE reqId=:reqId";
			TypedQuery<Integer> tQuery = entityManager.createQuery(qry, Integer.class);
			tQuery.setParameter("reqId",  reqId);
			quantity=tQuery.getSingleResult();
		
			
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			throw new AdminException("SQL EXCEPTION ");
		}
		
			return quantity;
	}
	
	
	private boolean updateQuantity(int aId,int quantity) throws AdminException {
		
		boolean flag = false;
		Asset asset =null;
	
			try {
				asset = getAssetDetails(aId);
				if(asset.getAssetQuantity() >= quantity)
				{
					asset.setAssetQuantity(quantity);
					entityManager.merge(asset);
					entityManager.flush();

					
					flag= true;
				}
				else
				{
					
					throw new AdminException("Sorry requested quantity of asset is/are not available");
				}
		
			}
			catch(Exception e)
			{
				throw new AdminException("Unable To Update The Quantity Due To Database Error");
			}
			return flag;
				
}
	
	
	public AssetAllocation selectRequest(int reqId) throws AdminException
	{
		AssetAllocation aa =new AssetAllocation();
		Request req = new Request();
		try
		{
			String qry="SELECT req FROM Request req WHERE reqId=:reqId";
			TypedQuery<Request> tQuery = entityManager.createQuery(qry, Request.class);
			tQuery.setParameter("reqId",  reqId);
			req=tQuery.getSingleResult();
			
			
			aa.setAssetId(req.getAssetId());
			aa.setEmpNo(req.getEmpNo());
			aa.setReleaseDate(req.getReleaseDate());

			
		}
		catch (Exception e)
		{
			throw new AdminException("SQL EXCEPTION ");
		}
		return aa;
	}
	
		private void insertAsset(AssetAllocation aa) throws AdminException 
		{
			LocalDate localDate = LocalDate.now();
			aa.setAllocationDate(Date.valueOf(localDate));
			
			
			try 
			{
				
				entityManager.persist(aa);
		
			} 
			catch (Exception e)
			{
				
				throw new AdminException("Unable To Insert The Asset Into The Database");
			}
		
	}
	

	
	// *********************** End Of Accepting The Request Of The Asset ************************************** //
	
	
	@Override
	public boolean rejectManagerRequest(int reqId) throws AdminException {
		
		boolean flag=false;
		
		Request req = new Request();
		try 
		{
			
			req = entityManager.find(Request.class, reqId);
			req.setStatus("REJECTED");
			
			entityManager.merge(req);
			entityManager.flush();
			
			AssetAllocation aa=selectRequest(reqId);
			
			insertAsset(aa);
			flag=true;		
			
			
		}
		catch(Exception e)
		{
			throw new AdminException("Unable To Reject Request Because Of Database Error");
		}
		return flag;
	}
	
	

		
}





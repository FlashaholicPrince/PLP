package com.cg.ams.dao;


import java.util.ArrayList;


import java.util.HashMap;
import java.util.List;

import com.cg.ams.bean.Asset;
import com.cg.ams.bean.Request;
import com.cg.ams.bean.UserMaster;
import com.cg.ams.exception.ManagerException;

public interface ManagerDao
{
	// Validate Manager Credentials
	
	
	//View Asset's And Request
	
	
	// View Available Asset And Raise Request
	
	public List<Asset> viewAssets() throws ManagerException;
	public boolean insertFormDetails(Request req) throws ManagerException;
	ArrayList<Integer> getEmployees(int mgrNo) throws ManagerException;

	
	
	
	// View Status And Delete Requests
	public List<Request> viewStatus(int userId) throws ManagerException;
	boolean deleteRequest(int reqId) throws ManagerException;

	UserMaster validateManager(int userid, String pwd, String usertype) throws ManagerException;
}

package com.cg.ams.test;

import static org.junit.Assert.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.HashMap;
import org.junit.Before;
import org.junit.Test;

import com.cg.ams.bean.Asset;
import com.cg.ams.bean.Request;
import com.cg.ams.dao.*;
import com.cg.ams.exception.ManagerException;
import com.cg.ams.service.ManagerServiceI;


public class ManagerTestCase {
	ManagerServiceI service = new ManagerServiceI();
	ManagerDao dao = new ManagerDaoI();
	@Before
	 public void init()
	{
		service.setDao(dao);
	}
	
	@Test
	public void testInsertFormDetailsPass() {
		
		
		Request request = new Request();
		request.setReqId(1015);
		request.setMgrNum(100002);
		request.setEmpNo(100007);
		request.setAssetId(100);
		request.setAssetQuantity(51);
		request.setStatus("PENDING");
		LocalDate rrDate = LocalDate.parse("2018-09-18");
		Date sqlDate =Date.valueOf(rrDate);
		request.setReleaseDate(sqlDate);
		
		boolean flag;
		try {
			flag = dao.insertFormDetails(request);
			assertEquals(flag,true);
		} catch (ManagerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Test
	public void testInsertFormDetailsFail() {
		Request request = new Request();
		request.setReqId(1000);
		request.setMgrNum(100002);
		request.setEmpNo(100007);
		request.setAssetId(111);
		request.setAssetQuantity(51);
		request.setStatus("PENDING");
		LocalDate rrDate = LocalDate.parse("2018-09-18");
		Date sqlDate =Date.valueOf(rrDate);
		request.setReleaseDate(sqlDate);
		//request.setReleaseDate("11-OCT-2016");
		
		boolean flag;
		try {
			flag = dao.insertFormDetails(request);
			assertEquals(flag,true);
		} catch (ManagerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Test
	public void testViewAssetsPass() {
		HashMap<Integer, Asset> map;
		try {
			map = dao.viewAssets();
			assertNotNull(map);
		} catch (ManagerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	@Test(expected=ManagerException.class)
	public void testViewAssetsFail() {
		HashMap<Integer, Asset> map;
		try {
			map = dao.viewAssets();
			assertNotNull(map);
		} catch (ManagerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}

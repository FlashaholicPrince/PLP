package com.cg.ams.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Request {
	
	@Column(name="mgr")
	@NotNull(message = "Manager Number Cannot be Empty")
	private int mgrNum;
	
	@Column(name="assetId")
	private int assetId;
	
	@Column(name="Quantity")
	@NotNull(message = "Asset Quantity Cannot be Empty")
	private int assetQuantity;
	
	@Column(name="status")
	@NotEmpty(message = "Status Cannot be Empty")
	private String status;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "myseq")
	@SequenceGenerator(name="myseq",sequenceName="REQID", initialValue = 1)
	@Column(name="reqId")
	private int reqId;
	
	@Column(name="release_Date")
	//@NotEmpty(message = "Release Date Cannot be Empty")
	private Date releaseDate;
	
	@Column(name="empNo")
	@NotNull(message = "Employee Number Cannot be Null")
	private int empNo;
	
	
	public int getMgrNum() {
		return mgrNum;
	}
	public void setMgrNum(int mgrNum) {
		this.mgrNum = mgrNum;
	}
	public int getAssetId() {
		return assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	
	public int getAssetQuantity() {
		return assetQuantity;
	}
	public void setAssetQuantity(int assetQuantity) {
		this.assetQuantity = assetQuantity;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getReqId() {
		return reqId;
	}
	public void setReqId(int reqId) {
		this.reqId = reqId;
	}
	public Date getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	@Override
	public String toString() {
		return "Request [mgrNum=" + mgrNum + ", assetId=" + assetId
				+  ", assetQuantity=" + assetQuantity + ", status=" + status
				+ ", reqId=" + reqId + ", releaseDate=" + releaseDate
				+ ", empNo=" + empNo + "]";
	}
	
}

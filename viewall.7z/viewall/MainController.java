package com.cg.ams.controller;


import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


import com.cg.ams.bean.Request;
import com.cg.ams.bean.UserMaster;
import com.cg.ams.exception.AdminException;
import com.cg.ams.exception.ManagerException;
import com.cg.ams.service.AdminService;
import com.cg.ams.service.AdminServiceImpl;
import com.cg.ams.service.ManagerService;
import com.cg.ams.service.ManagerServiceImpl;


@Controller
public class MainController
{
		
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private ManagerService managerService;
	
	

	public ManagerService getManagerService() {
		return managerService;
	}


	public void setManagerService(ManagerService managerService) {
		this.managerService = managerService;
	}


	public MainController(AdminService adminService,
			ManagerService managerService) {
		super();
		this.adminService = adminService;
		this.managerService = managerService;
	}


	public AdminService getAdminService() {
		return adminService;
	}


	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}



	public MainController(AdminService adminService) {
		super();
		this.adminService = adminService;
	}


	public MainController() {
		super();
		// TODO Auto-generated constructor stub
	}




	@RequestMapping("Login")
	public String getAdminHomePage(@RequestParam("id") int id, @RequestParam("pwd") String pwd, @RequestParam("usertype") String usertype)
	{			System.out.println("abcscsc"+id+pwd+usertype);

		UserMaster user = null;
		if(usertype.equalsIgnoreCase("admin"))
		{
			System.out.println("fdfaefaf"+id+pwd+usertype);
			try 
			{
				user = adminService.validateAdmin(id, pwd, usertype);
				System.out.println("user"+user);
				if(user != null)
				{
						return "Admin";
				}
				else
				{
					return "index";
				}
				
			}
			catch (AdminException e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			
				try 
				{
					user = managerService.validateManager(id, pwd, usertype);
					if(user != null)
					{
							return "Manager";
					}
					else
					{
						return "index";
					}
				} 
				catch (ManagerException e) 
				{
				
					e.printStackTrace();
				}
				
		
		}
		return "index";
	}
	
	
	@RequestMapping("AddAsset")
	public String getAddAssetPage()
	{
		return "Addassets";
	}
	
	
/*	@RequestMapping("viewallproducts")
	public String getViewAllProductsPage(Model model)
	{
		List<Product> products=null;
		try
		{
			products=productService.getAllProducts();
			model.addAttribute("products",products);
			return "ViewAllProductsPage";
		} 
		catch (Exception e)
		{
			model.addAttribute("errMsg","Could Not Display Product.Reason:" +e.getMessage());

			return "ErrorPage";
		}
		
	}*/
	
	@RequestMapping("ViewAllRequest")
	public String getViewAllRequestPage(Model model)
	{
		HashMap<Integer,Request> request = null;
		try
		{
			request=adminService.viewAllRequest();
			model.addAttribute("requests",request);
		} 
		catch (Exception e)
		{
			model.addAttribute("errMsg","Could Not Display Request.Reason:" +e.getMessage());

			return "ErrorPage";
		}
		return "viewAllRequest";
	}
}

package com.cg.ams.bean;

import java.sql.Date;

public class Request {
	
	private int mgrNum;
	private int assetId;
	private int assetQuantity;
	private String status;
	private int reqId;
	private Date releaseDate;
	private int empNo;
	public int getMgrNum() {
		return mgrNum;
	}
	public void setMgrNum(int mgrNum) {
		this.mgrNum = mgrNum;
	}
	public int getAssetId() {
		return assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	
	public int getAssetQuantity() {
		return assetQuantity;
	}
	public void setAssetQuantity(int assetQuantity) {
		this.assetQuantity = assetQuantity;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getReqId() {
		return reqId;
	}
	public void setReqId(int reqId) {
		this.reqId = reqId;
	}
	public Date getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	@Override
	public String toString() {
		return "Request [mgrNum=" + mgrNum + ", assetId=" + assetId
				+  ", assetQuantity=" + assetQuantity + ", status=" + status
				+ ", reqId=" + reqId + ", releaseDate=" + releaseDate
				+ ", empNo=" + empNo + "]";
	}
	
}

package com.cg.ams.logger;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
import org.apache.log4j.WriterAppender;


public class DaoLogger {
	
	//all are static

	public static Logger mylogger = Logger.getLogger(DaoLogger.class);
	
	static WriterAppender appender=null;
	
	static SimpleLayout layout=new SimpleLayout();
	
	static
	{
		try
		{
			
		
		FileOutputStream fout=new FileOutputStream("D:/MiniProject/Logging_AssetManagement System/Logger.txt");
		appender=new WriterAppender(layout,fout);
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		
		mylogger.addAppender(appender);
	}
	
}
